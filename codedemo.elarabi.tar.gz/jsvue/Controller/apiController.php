<?php
namespace Application\Controller;

use \Application\Model\foodsEntity;
use \Application\Model\foodgroupsEntity;

/***
 * Controller Api to allow communication with the exterior
 * We need tio implement the CRUD-Actions in this one for each Object
 * 
 * For the demo purpose this controller implemented the 
 *  Get action only
 * TODO add the actions:  CREATE, UPDATE and DELETE handles
 * 
 */
class apiController {
    ## For the demo porpose we set the variable with an empty set-data for each entity
    public $entries  = array(
            "foudgroups" => array(),
            "foods" => array()
        );

    ## Food groups Id to filter valid inputs
    public $foodGroupIds = array(
            'vf' => 'vf',
            'gr' => 'gr', 
            'da' => 'da', 
            'me' => 'me'
        );

    /** 
     * ## Function to retrieve food-records from the database!
    */
    public function getFoods(){
        ##Get the value of the food groups we look to get the foods list for.
        $fg = $this->getFoodGroupId();

        #Get an instance of the model and load the requested data
        $entity = new foodsEntity();
        $this->entries = $entity->fetchAll($fg);
    }
    /**
     * Retrive food-groups from the database!
     */
    public function getGroups(){
        $entity = new foodgroupsEntity();
        $this->entries = $entity->fetchAll();
    }

    private function getFoodGroupId(){
        ##Get the value of the food groups we look to get the foods list for.
        $fg = !empty($_POST['fg'])?$_POST['fg']:'gr';
                
        #Check if the giving Input is valid
        if(array_key_exists($fg, $this->foodGroupIds)) {
            $fg = $this->foodGroupIds[$fg];
        } else {
            #For the purpose to donnot throw an error its a demo!
            $fg = 'da';
        }

        return $fg;            
    }
    /**
     * Ta
     */
    public function retrieveEntries(){
        #return $this->entries;
        ## Bring out the requested data from the database
        try {
            if(isset($_GET['foods'])) {
                $this->getFoods();
            } elseif(isset($_GET['groups'])) {
                $this->getGroups();
            } 
        } catch (\Exception $e){
            ##Log the error and send the a status result to the client
            return array(
                'status' => 'error', 
                'message' => 'Cannot access data resources: '
            );
        } 
    
        return $this->entries;
    }
}
