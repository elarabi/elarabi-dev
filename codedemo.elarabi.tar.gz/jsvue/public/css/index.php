<?php header('Content-type: text/css'); ?>
body {
    background-color: #eeeeee;
}
