<?php
include_once(__DIR__.'/../../Config/init.php');

use \Application\Controller\apiController;

$app = new apiController();

$results = array(
    'status'=> 'Ok', 
    'rows' => $app->retrieveEntries(),
    );
##send the results to the client 
echo json_encode($results);