var foodGuideApp = new Vue({
    el: '#foodGuidePage',
    data: {
        message: 'This file-sample is built in the objective to show the use of Fondation a CSS-Framework and VueJs a javascript Framework',
        foodGroups: [],
        foodsList: [],
        loadingError: "",
        loadingProgress:""
    },
    
    methods: {
        getGroups: function (){
            var url = '/api/?groups=json';
            var vm = this;
            
            vm.loadingProgress = 'Loading in progress ... Thinking...';
            
            axios.get(url)
                .then(function (response) {
                    //console.log(response.data);
                    console.log('Showing rows-dat-response ', response.data.rows);
                    var foodRows = response.data.rows;//JSON.parse(response.data.rows);  
                    vm.foodGroups = foodRows.foodgroups;//response.data.rows;
                    console.log("Showing rows!!!!!",vm.foodGroups);                
                })
                .catch(function (error) {
                   vm.loadingError = 'Unexpected error! Cannot get results. ' + error; 
                  console.log( vm.loadingError);
                })
        },
        getFoods: function (params){
            var url = '/api/?foods=json';
            var vm = this;
            var postInputs = { 
                    foods: 'json',
                    fg: params,
                    food_group: 'gr',
                };
            var postData = "fg="+params;
            console.log("Food Group",postData);
            axios.post("/api/?foods=json", postData
            ).then(function (response) {
                console.log("Showing Foods-rows response ",response.data.rows);
                var foodRows = response.data.rows;//JSON.parse(response.data.rows);  
                vm.foodsList = foodRows.foods;
                //vm.foodsList.push({"title":"food Goup No Specified!!!","url":"https:://url.com/food-toload"});
                console.log(response.data);
                console.log(response.status);
                console.log(response.statusText);
                console.log(response.headers);
                console.log(response.config);
            }).catch (function(error){
                console.log(error);
            })
        }
           
    }
});

//foodGuideApp.set()

$(document).foundation();
