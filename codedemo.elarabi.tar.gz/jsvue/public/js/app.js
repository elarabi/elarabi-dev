var foodGuideApp = new Vue({
    el: '#foodGuidePage',
    data: {
        message: 'This file-sample is built in the objective to show the use of Fondation a CSS-Framework and VueJs a javascript Framework',
        foodGroups: [],
        foodsList: [],
        loadingError: "",
        loadingProgress:""
    },
    
    methods: {
        getGroups: function (){
            var url = '/api/?groups=json';
            var vm = this;
            
            vm.loadingProgress = 'Loading in progress ... Thinking...';
            
            axios.get(url)
                .then(function (response) {
                    console.log('Showing rows-dat-response ', response.data.rows);
                    var foodRows = response.data.rows;
                    vm.foodGroups = foodRows.foodgroups;
                })
                .catch(function (error) {
                   vm.loadingError = 'Unexpected error! Cannot get group-records from the server! ' + error; 
                  console.log( vm.loadingError);
                })
        },
        getFoods: function (params){
            var url = '/api/?foods=json';
            var vm = this;
            var postData = "fg="+params;
            vm.loadingProgress = 'Loading in progress ... Thinking...';
            axios.post("/api/?foods=json", postData)
                .then(function (response) {
                    console.log("Showing Foods-rows response ",response.data.rows);
                    var foodRows = response.data.rows;
                    vm.foodsList = foodRows.foods;
            }).catch (function(error){
                vm.loadingError = 'Unexpected error! Cannot get food-records from the server! ' + error; 
                console.log(vm.loadingError);
            })
        }
           
    }
});


$(document).foundation();
