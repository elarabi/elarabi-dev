<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Demo App for VueJs a JavaScript Framework</title>

  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css" />
  <link rel="stylesheet" href="/css/app.css" />
</head>
<body>
  <div class="row"><h1>Food Guide!</h1></div>

<nav class="top-bar"  data-topbar>  
  <div class="top-bar-left"></div>
  <ul class="menu">
    <li class="menu-text"><i class="fi-home"></i>Demo</li>
    <li><a href="#"><i class="fi-camera"></i> <span>About</span></a></li>
    <li><a href="#"><i class="fi-mountains"></i> <span>Groups</span></a></li>
    <li><a href="#"><i class="fi-trees"></i> <span>Foods</span></a></li>
    <li><a href="#"><i class="fi-telephone"></i> <span>Contact</span></a></li>
  </ul>
</nav>

<div class="row" id="foodGuidePage">
<div class="large-12 columns"><blockquotes> {{ message }}</blockquotes></div>
  <div class="large-4 columns">
    <div class="callout panel"  id="appSide">
      <h3>Food Groups</h3>
      <div>    
        
        <p><span><a href="#" v-on:click="getGroups()">Click me to load food groups</a></span></p>
      </div>  
      <div>
      <ul class="unstyled">
        <li v-for="item in foodGroups" :key="item.fgid" >
           <a v-on:click="getFoods(item.fgid)"> {{item.fgid}} - {{item.foodgroup}} <span v-if="item.categories">({{item.categories.length}})</span></a>
        </li>
      </ul> 
      </div>
    </div>
  </div>
  <!-- aside -->
  <div class="large-8 columns">
    <div class="callout panel" id="appBody">
      <h3>Foods List</h3>
      <div  class="table-scroll">
      <table>
        <thead>
          <tr>
            <th>Food Group</th>
            <th>Food</th>
            <th>Serving Average</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in foodsList" :key="row.fgid">
            <td> {{row.fgid}}-{{row.fgcat_id}} </td>
            <td>{{row.food}}</td>
            <td>{{row.srvg_sz}}</td>
          </tr>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
<script src="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash"></script>
<script src="https://cdn.jsdelivr.net/npm/vue"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script src="/js/app.js"></script>
</body>
</html>
