<?php
////--------------------------------------------------       --------------------------------------------------------------\\\
spl_autoload_register("__autoload");
//Define autoload function 
function __autoload($class_name) {
     
    if(!class_exists($class_name))
    {
      $filePath = realpath(__DIR__.'/../');
      $fileName = str_replace(array('Application', '\\'), array($filePath,DIRECTORY_SEPARATOR ), $class_name).'.php';
      if(is_file($fileName )){
        @require_once $fileName;
      }
    }
    if(class_exists($class_name)) {
        return TRUE;
    } else {
        @error_log(__LINE__."- Looking to include the file $fileName to load the class '$class_name' from the path $filePath ");
        throw( new Exception("Classe '.$class_name' not found "));
        return FALSE;
    }

}
//// -----------------------------------------------------------                 -------------------------------------------\\\\\\\\


error_reporting (E_ALL);
