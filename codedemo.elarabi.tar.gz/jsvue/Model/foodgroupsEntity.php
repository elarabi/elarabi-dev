<?php
namespace Application\Model;

use \Application\Model\abstractEntity;

class foodgroupsEntity  extends abstractEntity {
  
  public function __construct(){
        #File data source for the foodgroups entity
        $fileName = 'foodgroups.json';
        
        $memberKey = 'foodgroups';
        
        $fields = array (
                'fgid' => 'Group ID',
                'foodgroup' => 'Group Name',
                'categories' => 'Sub Groups'
        );
        parent::__construct($fileName, $memberKey, $fields);
  }
  public function fetchAll(){
        $allRows = $this->loadData();
        
        $groups = array ();
        foreach($allRows as $key => $row ) {
            $fgid = (string)$row->fgid;
            $groups["{$fgid}"] = (object)array(
                       'fgid' =>  (string)$row->fgid,
			'foodgroup' => (string)$row->foodgroup,
			'categories' => (array)$row->categories,
                );

       }
       ksort($groups );
      return array("foodgroups" => array_values($groups));
}
}
/*
function getModel ($fileIndex) {

	$files = array(
		'fg_directional_satements-en.json',
		'foods-en.json',
		'foodgroups-en.json',
		'servings_per_day-en.json'
	); 
	$fields = array(
		'fg_directional_satements-en.json'=>array('fgid','dir_stmt'),
		'foods-en.json'=>array('fgid','fgcat_id', 'srvg_sz', 'food'),
		'foodgroups-en.json' => array('fgid','foodgroup','categories'),
		'servings_per_day-en.json' => array('fgid','gender','ages','servings'),
	);
	$propertyNames= array(
		'directional_statements',
		'foods',
		'foodgroups',
		'servings to per to miy',
	);
	$dataPath = realpath(__DIR__.'/../').'/data/en/';
	$contents = file_get_contents($dataPath.$files[$fileIndex]); 
	#print('<p class=""><b> Model Loaded:<br>'.$dataPath.$files[$fileIndex].'</b><p>');
	$contents = utf8_encode($contents); 
	$results = json_decode($contents); 

       
	$property = $propertyNames[$fileIndex];
	return $results->{$property};
}
function loadStatments( ){
	$rows = (array)getModel(0);
        $foodGuids = array ();
        foreach($rows as $key =>$row ) {
             $foodGuids["{$row->fgid}-{$key}"] = $row->dir_stmt;
       }
      return  $foodGuids;
}
function findPortionPerDay( $gender, $ages){
	$rows = (array)getModel(3);
        $foodGuids = array ();
        foreach($rows as $key =>$row ) {
		if(((string)$row->gender === $gender) && ((string)$row->ages === $ages)){
             	   $foodGuids[] = array(
                        'fgid' => $row->fgid,
                        'servings' => $row->servings,
                         	
			);
        	}
       }
      return array("{$gender}-{$ages}" => $foodGuids);
}
function findFoodsByGroup($fgid) {
     $rows = getModel(1);
        $foodGuids = array ();
        foreach($rows as $key =>$row ) {
                if(((string)$row->fgid === $fgid) ){
                   $foodGuids["{$fgid}{$row->fgcat_id}-{$key}"] = array(
			'fgcat_id' => (string)$row->fgcat_id,
			'srvg_sz' => (string)$row->srvg_sz,
                        'food' => (string)$row->food,
                        );
                }
       }
       ksort($foodGuids );
      return array("{$fgid}" => $foodGuids);
}
function loadSubFoodGroups() {
        $rows = (array)getModel(2);
        $subFoodGroups = array ();
        $foodGroups = array();
        foreach($rows as $key =>$row ) {
             $foodGroups[$row->fgid] = $row->foodgroup;
             if(!empty($row->categories)){
             	foreach($row->categories as $cat)
                 $subFoodGroups["{$row->fgid}-{$cat->fgcat_id}"] = "{$row->foodgroup} - {$cat->fgcat}";
             }
             #else{ echo '<pre>'; var_dump($row); echo '</pre>';}
       }
      #if(!empty($foodGuids)){ echo '<pre>'; var_dump($groups ); echo '</pre>';}
      return  array('groups' => $foodGroups, 'subgroups' => $subFoodGroups );

} */