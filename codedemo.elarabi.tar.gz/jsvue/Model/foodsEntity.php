<?php
namespace Application\Model;

use \Application\Model\abstractEntity;

class foodsEntity  extends abstractEntity {
  
  public function __construct(){
        $fileName = 'foods.json';
        $memberKey = 'foods';
        $fields = array(
              'fgid' => "Group" ,
              'fgcat_id' => "Sub Gourp", 
              'srvg_sz'  => "Avg Serving", 
              'food' => "Food"
        );
        parent::__construct($fileName, $memberKey, $fields);
  }
  public function fetchAll($fgid){
        $allRows = $this->loadData();
        
        $foods = array ();
        foreach($allRows as $key => $row ) {
                if(((string)$row->fgid === $fgid) ){
                   $foods["{$fgid}{$row->fgcat_id}-{$key}"] = (object)array(
                                'fgid' =>  (string)$row->fgid,
			        'fgcat_id' => (string)$row->fgcat_id,
			        'srvg_sz' => (string)$row->srvg_sz,
                                'food' => (string)$row->food,
                        );
                }
       }
       ksort($foods );
      return array("foods" => array_values($foods));
 }
}		
