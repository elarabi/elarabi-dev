<?php
namespace Application\Model;

class abstractEntity {

    private $_dataDirectory;
    private $_fileName;
    private $_memberKey;
    private $_fields = array();
    
    ##Dependency injection
    public function __construct ( $fileName, $memberKey, $fields){
            $this->_fileName = $fileName;
            $this->_memberKey = $memberKey;
            $this->_fields = $fields;

            $this->_dataDirectory = realpath(__DIR__).'/data/';
    }

    ##TODO Add Setter Getter Methods

    ##For the demo purpose and to emulate the Databse Access 
    public function loadData () {
                
        $dataFilePath = $this->_dataDirectory.$this->_fileName;
        $contents = file_get_contents($dataFilePath); 
        
        #die($contents);
        $contents = utf8_encode($contents); 
        $results = json_decode($contents); 
        ##TODO add errors handling
            
        return $results->{$this->_memberKey};
    }
}